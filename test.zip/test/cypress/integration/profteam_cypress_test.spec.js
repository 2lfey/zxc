describe("Cypress tests", () => {
    it("login test", () => {
        cy.fixture("cypressTests").then(data => {
            cy.log("Переход на страницу авторизации")
            cy.visit(data.login_url)

            cy.log("Ввод логина")
            cy.get("input[class='form-input--text form-input']")
                .type(data.login)

            cy.log("Ввод пароля")
            cy.get("input[class='form-input--password form-input']")
                .type(data.password)

            cy.log("Клик по кнопке 'Войти'")
            cy.get("button[class='button button__background-color-green']")
                .click()

            
        })
    })
})