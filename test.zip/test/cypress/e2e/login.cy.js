describe("Cypress tests", () => {
  it("login test", () => {
    cy.fixture("cypressTests").then(data => {
      cy.log("Переход на страницу авторизации")
      cy.visit(data.login_url)

      cy.log("Ввод логина")
      cy.log("Логина", data.login)
      cy.get("input[class='form-input--text form-input']")
        .type(data.login)

      cy.log("Ввод пароля")
      cy.log("Пароль", data.password)
      cy.get("input[class='form-input--password form-input']")
        .type(data.password)
      cy.wait(200)


      cy.log("Клик по кнопке 'Войти'")
      cy.get('.form__buttons > :nth-child(3)')
        .click()
      
      

      // cy.url().should("include", "/account/main")

      // cy.get("h2[class='page-title']")
      //   .should("Личный кабинет")
    
    })
  })
})
