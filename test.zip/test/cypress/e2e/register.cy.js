describe("Cypress tests", () => {
  it("register test", () => {
    cy.fixture("cypressTests").then(data => {
      cy.log("Переход на страницу авторизации")
      cy.visit(data.register_url)

      cy.log("Ввод почты")
      cy.log("Почты", data.non_exist_email)
      cy.get('.form-input--email')
        .type(data.non_exist_email)
      

      cy.log("Ввод логина")
      cy.log("Логина", data.non_exist_login)
      cy.get(':nth-child(1) > :nth-child(1) > .form-control--medium > .form-input--text')
        .type(data.non_exist_login)

      cy.log("Ввод пароля")
      cy.log("Пароль", data.non_exist_password)
      cy.get(':nth-child(3) > .form-control--medium > .form-input--password')
        .type(data.non_exist_password)

      
      cy.log("Ввод повтора пароля")
      cy.log("Пароль", data.non_exist_password)
      cy.get(':nth-child(4) > .form-control--medium > .form-input--password')
        .type(data.non_exist_password)

      cy.wait(200)

      cy.log("Клик по кнопке 'Регистрация'")
      cy.get(':nth-child(4) > .button')
        .click()
      
      // cy.wait(200)

      // cy.url().should("include", "/account/main")

      // cy.get("h2[class='page-title']")
      //   .should("Личный кабинет")
    
    })
  })
})
